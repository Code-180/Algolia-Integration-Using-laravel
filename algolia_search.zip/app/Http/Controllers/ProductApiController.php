<?php

namespace App\Http\Controllers;

use App\Models\Products;
use Illuminate\Http\Request;
use Validator;

class ProductApiController extends Controller
{
    public function __construct()
    {
        //$this->middleware('auth');
    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    /**
     * @queryParam
     */
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function list(Request $request)
    {
        //++++++++++++++++++++++++++++++++++++++++++++++
        $respond = [];
        //++++++++++++++++++++++++++++++++++++++++++++++
        try {
            //++++++++++++++++++++++++++++++++++++++++++++++
            $obj = Products::all();
            //++++++++++++++++++++++++++++++++++++++++++++++
            $respond['status']   = true;
            $respond['message']  = 'Get';
            $respond['response'] = $obj;
        } catch (\Exception $e) {
            $respond['status']        = false;
            $respond['message']       = $e->getMessage();
            $respond['response_data'] = null;
        }
        return $respond;
    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    /**
     * @queryParam
     */
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function searching(Request $request)
    {
        //++++++++++++++++++++++++++++++++++++++++++++++
        $respond = [];
        //++++++++++++++++++++++++++++++++++++++++++++++
        try {
            //++++++++++++++++++++++++++++++++++++++++++++++
            $obj_1 = Products::search($request->title)->get();
            $obj_2 = Products::search($request->title)->count();
            $obj_3 = Products::search($request->title)->where('product_price', '>', 100)->get();
            $obj_4 = Products::search($request->title)->where('created_at', '>=', now()->subDays(7))->get();
            $obj_5 = Products::search($request->title)->where('product_discount_price', 100)->get();
            $obj_6 = Products::search($request->title)->whereBetween('price', [100, 200])->get();
            //$obj_7 = Products::search($request->title)->whereIn('id', [1, 2])->get();
            //++++++++++++++++++++++++++++++++++++++++++++++
            $respond['response'] = [
                "obj_1" => $obj_1,
                "obj_2" => $obj_2,
                "obj_3" => $obj_3,
                "obj_4" => $obj_4,
                "obj_5" => $obj_5,
                "obj_6" => $obj_6,
            ];
            //++++++++++++++++++++++++++++++++++++++++++++++
            $respond['status']  = true;
            $respond['message'] = 'Search';
        } catch (\Exception $e) {
            $respond['status']        = false;
            $respond['message']       = $e->getMessage();
            $respond['response_data'] = null;
        }
        return $respond;
    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    /**
     * @queryParam
     */
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function add(Request $request)
    {
        //++++++++++++++++++++++++++++++++++++++++++++++
        $respond = [];
        //++++++++++++++++++++++++++++++++++++++++++++++
        $validator = Validator::make($request->all(), [
            'product_title'          => 'required',
            'product_description'    => 'required',
            'product_price'          => 'required',
            'product_discount_price' => 'required',
        ]);
        //++++++++++++++++++++++++++++++++++++++++++++++
        if ($validator->fails()) {
            $respond['status']        = false;
            $respond['message']       = 'Validation Error';
            $respond['response_data'] = $validator->messages();
        } else {
            try {
                //+++++++++++++++++++++++++++++++++++++++++++++++++++++
                $obj = new Products;
                //+++++++++++++++++++++++++++++++++++++++++++++++++++++
                $obj->product_title          = $request->product_title;
                $obj->product_description    = $request->product_description;
                $obj->product_price          = $request->product_price;
                $obj->product_discount_price = $request->product_discount_price;
                //++++++++++++++++++++++++++++++++++++++++++++++++++++++
                $obj->save();
                //++++++++++++++++++++++++++++++++++++++++++++++++++++++
                $respond['status']   = true;
                $respond['message']  = 'Successfully added.';
                $respond['response'] = Products::find($obj->id);
            } catch (\Exception $e) {
                $respond['status']        = false;
                $respond['message']       = $e->getMessage();
                $respond['response_data'] = null;
            }
        }
        return $respond;
    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    /**
     * @queryParam
     */
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function update(Request $request)
    {
        //++++++++++++++++++++++++++++++++++++++++++++++
        $respond = [];
        //++++++++++++++++++++++++++++++++++++++++++++++
        $validator = Validator::make($request->all(), [
            'id'                     => 'required',
            'product_title'          => 'required',
            'product_description'    => 'required',
            'product_price'          => 'required',
            'product_discount_price' => 'required',
        ]);
        //++++++++++++++++++++++++++++++++++++++++++++++
        if ($validator->fails()) {
            $respond['status']        = false;
            $respond['message']       = 'Validation Error';
            $respond['response_data'] = $validator->messages();
        } else {
            try {
                //+++++++++++++++++++++++++++++++++++++++++++++++++++++
                $obj = Products::find($request->id);
                //+++++++++++++++++++++++++++++++++++++++++++++++++++++
                $obj->product_title          = $request->product_title;
                $obj->product_description    = $request->product_description;
                $obj->product_price          = $request->product_price;
                $obj->product_discount_price = $request->product_discount_price;
                //++++++++++++++++++++++++++++++++++++++++++++++++++++++
                $obj->save();
                //++++++++++++++++++++++++++++++++++++++++++++++++++++++
                $respond['status']   = true;
                $respond['message']  = 'Successfully updated.';
                $respond['response'] = Products::find($obj->id);
            } catch (\Exception $e) {
                $respond['status']        = false;
                $respond['message']       = $e->getMessage();
                $respond['response_data'] = null;
            }
        }
        return $respond;
    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    /**
     * @queryParam
     */
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function destroy(Request $request)
    {
        //++++++++++++++++++++++++++++++++++++++++++++++
        $respond = [];
        //++++++++++++++++++++++++++++++++++++++++++++++
        $validator = Validator::make($request->all(), [
            'id' => 'required',
        ]);
        //++++++++++++++++++++++++++++++++++++++++++++++
        if ($validator->fails()) {
            $respond['status']        = false;
            $respond['message']       = 'Validation Error';
            $respond['response_data'] = $validator->messages();
        } else {
            try {
                //++++++++++++++++++++++++++++++++++++++++++
                Products::destroy($request->id);
                //++++++++++++++++++++++++++++++++++++++++++
                $respond['status']   = true;
                $respond['message']  = 'Successfully deleted.';
                $respond['response'] = null;
            } catch (\Exception $e) {
                $respond['status']        = false;
                $respond['message']       = $e->getMessage();
                $respond['response_data'] = null;
            }
        }
        return $respond;
    }
//End
}
