<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Scout\Searchable;

// php artisan scout:import

class Blog extends Authenticatable
{
    use Searchable;
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'blog_title',
        'blog_description',
        'blog_tag',
    ];
}
